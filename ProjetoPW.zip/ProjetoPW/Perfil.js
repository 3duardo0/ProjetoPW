function curtir(btn) {
    let span = btn.querySelector("span");
    let count = parseInt(span.innerText) || 0;

    if (btn.classList.contains("liked")) {
        span.innerText = count - 1;
        btn.classList.remove("liked");
    } else {
        span.innerText = count + 1;
        btn.classList.add("liked");
    }
}

function addFavorito() {
    let input = document.getElementById("novoFav");
    let valor = input.value;

    if (valor.trim() === "") return;

    let div = document.createElement("div");
    div.classList.add("fav-item");

    div.innerHTML = `
        ${valor} 
        <button onclick="this.parentElement.remove()">❌</button>
    `;

    document.getElementById("favoritos").appendChild(div);

    input.value = "";
}
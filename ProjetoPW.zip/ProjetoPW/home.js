// Função para curtir/descurtir um post
function curtir(btn) {
    // Pega o <span> dentro do botão (onde fica o número de curtidas)
    let span = btn.querySelector("span");

    // Converte o texto do span (string) para número
    let count = parseInt(span.innerText);

    // Verifica se já está curtido
    if (btn.classList.contains("liked")) {
        // Se já estiver curtido → diminui 1
        span.innerText = count - 1;

        // Remove a classe "liked"
        btn.classList.remove("liked");
    } else {
        // Se não estiver curtido → aumenta 1
        span.innerText = count + 1;

        // Adiciona a classe "liked"
        btn.classList.add("liked");
    }
}


// Função para adicionar um comentário
function comentar(btn) {
    // Pega o input que está antes do botão
    let input = btn.previousElementSibling;

    // Pega o texto digitado
    let texto = input.value;

    // Se estiver vazio, não faz nada
    if (texto.trim() === "") return;

    // Pega a div onde ficam os comentários
    let commentsDiv = btn.parentElement.previousElementSibling;

    // Cria uma nova div para o comentário
    let novoComentario = document.createElement("div");

    // Adiciona a classe "comment"
    novoComentario.classList.add("comment");

    // Coloca o texto dentro da div
    novoComentario.innerText = texto;

    // Adiciona o comentário na tela
    commentsDiv.appendChild(novoComentario);

    // Limpa o input depois de comentar
    input.value = "";
}


// Função para adicionar um novo post (resenha)
function adicionarPost() {
    // Pega os valores dos inputs
    let titulo = document.getElementById("titulo").value;
    let critica = document.getElementById("critica").value;

    // Se algum estiver vazio, não cria o post
    if (titulo.trim() === "" || critica.trim() === "") return;

    // Pega o container principal onde ficam os posts
    let container = document.querySelector(".container");

    // Cria uma nova div para o post
    let novoPost = document.createElement("div");
    novoPost.classList.add("post");

    // Estrutura do post (HTML interno)
    novoPost.innerHTML = `
      <h3>🎬 ${titulo}</h3>
      <p>${critica}</p>

      <div class="actions">
        <button onclick="curtir(this)">Curtir (<span>0</span>)</button>
      </div>

      <div class="comments"></div>

      <div class="add-comment">
        <input type="text" placeholder="Escreva seu comentário...">
        <button onclick="comentar(this)">Comentar</button>
      </div>
    `;

    // Adiciona o novo post no topo (logo após o primeiro elemento)
    container.insertBefore(novoPost, container.children[1]);

    // Limpa os inputs após criar o post
    document.getElementById("titulo").value = "";
    document.getElementById("critica").value = "";
}

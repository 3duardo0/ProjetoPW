function curtir(btn) {
    let span = btn.querySelector("span");
    let count = parseInt(span.innerText);

    if (btn.classList.contains("liked")) {
        span.innerText = count - 1;
        btn.classList.remove("liked");
    } else {
        span.innerText = count + 1;
        btn.classList.add("liked");
    }
}

function filtrarFilmes() {
    let input = document.getElementById("pesquisa").value.toLowerCase();
    let filmes = document.querySelectorAll(".filme-card");

    filmes.forEach(filme => {
        let titulo = filme.querySelector("h3").innerText.toLowerCase();

        if (titulo.includes(input)) {
            filme.style.display = "block";
        } else {
            filme.style.display = "none";
        }
    });
}